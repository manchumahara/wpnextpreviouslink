=== Codeboxr Next Previous Link ===
Contributors: manchumahara, codeboxr
Donate link: http://codeboxr.com
Tags: nextprev, navigation
Requires at least: 3.0
Tested up to: 3.9.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shows next previous page or article link using icons, have setting to configure as need.

== Description ==

Improve Your User’s Experience by Giving Easy Navigation For Site Content

Looking for a WordPress plugin that will enable your readers to go to next or previous articles without any complication, but with a single button click? Look no further. Our Show Next Previous Article Plugin for WordPress is just the right solution.


*   Simple and Fast Article Navigation
*   Comes with Pre-styled 8 Next/ Previous Buttons

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload folder `wpnextpreviouslink` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Check setting from the setting menu from admin panel

== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==

= 1.1 =
* First release


== Upgrade Notice ==



== Arbitrary section ==



